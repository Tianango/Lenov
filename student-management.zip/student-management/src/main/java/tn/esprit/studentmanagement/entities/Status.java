package tn.esprit.studentmanagement.entities;

public enum Status {
    ACTIVE,
    COMPLETED,
    DROPPED,
    FAILED,
    WITHDRAWN
}
